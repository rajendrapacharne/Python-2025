-- Assignment 3 answers
show databases

use empdb

-- Q1)-->

CREATE TABLE Orders (
    order_id INT PRIMARY KEY,
    order_date DATE,
    amount INT,
    customer_id BIGINT UNSIGNED,  -- Corrected: BIGINT UNSIGNED instead of UNSIGNED
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id) ON DELETE CASCADE
);



DESC Customer;

-- Q2)-->

INSERT INTO Orders (order_id, order_date, amount, customer_id)
VALUES 
    (1, '2025-03-01', 500, 1),
    (2, '2025-03-02', 750, 2),
    (3, '2025-03-03', 900, 3),
    (4, '2025-03-04', 600, 4),
    (5, '2025-03-05', 850, 5);


-- Q3)-->  
SELECT Customer.customer_id, Customer.first_name, Orders.order_id, Orders.amount
FROM Customer 
INNER JOIN Orders ON Customer.customer_id = Orders.customer_id;

-- Q4)-->

SELECT Customer.customer_id, Customer.first_name, Orders.order_id, Orders.amount
FROM Customer 
LEFT JOIN Orders ON Customer.customer_id = Orders.customer_id;


SELECT Customer.customer_id, Customer.first_name, Orders.order_id, Orders.amount
FROM Customer 
RIGHT JOIN Orders ON Customer.customer_id = Orders.customer_id;

-- Q5)-->
SELECT Customer.customer_id, Customer.first_name, Orders.order_id, Orders.amount
FROM Customer  
LEFT JOIN Orders ON Customer.customer_id = Orders.customer_id

UNION

SELECT Customer.customer_id, Customer.first_name, Orders.order_id, Orders.amount
FROM Customer  
RIGHT JOIN Orders ON Customer.customer_id = Orders.customer_id;


-- Q6)-->
UPDATE Orders 
SET amount = 100 
WHERE customer_id = 3;

