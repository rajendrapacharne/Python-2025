-- Case Study 1 solutions 
show databases

use empdb


CREATE TABLE FactTable (
    Date DATE,
    ProductID INT,
    Profit DECIMAL(10,2),
    Sales DECIMAL(10,2),
    Margin DECIMAL(10,2),
    COGS DECIMAL(10,2),
    TotalExpenses DECIMAL(10,2),
    Marketing DECIMAL(10,2),
    Inventory INT,
    BudgetProfit DECIMAL(10,2),
    BudgetCOGS DECIMAL(10,2),
    BudgetMargin DECIMAL(10,2),
    BudgetSales DECIMAL(10,2),
    AreaCode INT
);

CREATE TABLE ProductTable (
    ProductID INT PRIMARY KEY,
    ProductType VARCHAR(50),
    Product VARCHAR(100),
    Type VARCHAR(50)
);

CREATE TABLE LocationTable (
    AreaCode INT PRIMARY KEY,
    State VARCHAR(50),
    Market VARCHAR(50),
    MarketSize VARCHAR(50)
);

INSERT INTO FactTable VALUES
('2025-03-10', 1, 500.00, 1500.00, 0.33, 700.00, 200.00, 100.00, 50, 600.00, 650.00, 0.30, 1550.00, 101),
('2025-03-11', 2, 300.00, 1200.00, 0.25, 750.00, 250.00, 120.00, 40, 500.00, 550.00, 0.28, 1250.00, 102),
('2025-03-12', 3, 700.00, 1800.00, 0.39, 800.00, 300.00, 150.00, 60, 750.00, 800.00, 0.35, 1900.00, 103),
('2025-03-13', 4, 450.00, 1400.00, 0.32, 720.00, 210.00, 90.00, 55, 580.00, 620.00, 0.31, 1450.00, 104),
('2025-03-14', 5, 600.00, 1600.00, 0.37, 770.00, 270.00, 110.00, 70, 680.00, 730.00, 0.34, 1650.00, 105),
('2025-03-15', 6, 350.00, 1300.00, 0.27, 690.00, 230.00, 130.00, 45, 560.00, 590.00, 0.29, 1350.00, 106),
('2025-03-16', 7, 750.00, 1900.00, 0.40, 820.00, 320.00, 160.00, 80, 770.00, 850.00, 0.36, 1950.00, 107),
('2025-03-17', 8, 550.00, 1550.00, 0.35, 740.00, 260.00, 140.00, 65, 640.00, 690.00, 0.33, 1600.00, 108),
('2025-03-18', 9, 480.00, 1450.00, 0.33, 710.00, 220.00, 105.00, 58, 600.00, 640.00, 0.32, 1500.00, 109),
('2025-03-19', 10, 520.00, 1580.00, 0.34, 750.00, 240.00, 115.00, 63, 620.00, 670.00, 0.33, 1620.00, 110);




INSERT INTO ProductTable VALUES
(1, 'Beverage', 'Coffee', 'Regular'),
(2, 'Beverage', 'Tea', 'Premium'),
(3, 'Snack', 'Chips', 'Regular'),
(4, 'Dairy', 'Milk', 'Regular'),
(5, 'Beverage', 'Juice', 'Premium'),
(6, 'Snack', 'Biscuits', 'Regular'),
(7, 'Dairy', 'Cheese', 'Premium'),
(8, 'Beverage', 'Soft Drink', 'Regular'),
(9, 'Beverage', 'Energy Drink', 'Premium'),
(10, 'Snack', 'Popcorn', 'Regular');


INSERT INTO LocationTable VALUES
(101, 'California', 'West Coast', 'Large'),
(102, 'Texas', 'South', 'Large'),
(103, 'New York', 'East Coast', 'Medium'),
(104, 'Florida', 'South', 'Large'),
(105, 'Illinois', 'Midwest', 'Medium'),
(106, 'Colorado', 'West', 'Small'),
(107, 'Arizona', 'West', 'Small'),
(108, 'Georgia', 'South', 'Medium'),
(109, 'Nevada', 'West', 'Small'),
(110, 'Washington', 'West Coast', 'Large');



-- Q1)-->
SELECT COUNT(DISTINCT State) AS NumberOfStates FROM LocationTable;

-- Q2)-->
SELECT COUNT(*) AS RegularProductCount FROM ProductTable WHERE Type = 'Regular';

-- Q3)-->
SELECT SUM(Marketing) AS TotalMarketingSpent FROM FactTable WHERE ProductID = 1;

-- Q4)-->
 SELECT MIN(Sales) AS MinSales FROM FactTable;
 
 -- Q5)-->
 SELECT MAX(COGS) AS MaxCOGS FROM FactTable;
 
 -- Q6)-->
SELECT * FROM ProductTable WHERE ProductType = 'Coffee';

-- Q7)-->
SELECT * FROM FactTable WHERE TotalExpenses > 40;

-- Q8)-->
SELECT AVG(Sales) AS AvgSales FROM FactTable WHERE AreaCode = 719;

-- Q9)-->
SELECT SUM(f.Profit) AS TotalProfit
FROM FactTable f
JOIN LocationTable l ON f.AreaCode = l.AreaCode
WHERE l.State = 'Colorado';

-- Q10)-->
SELECT ProductID, AVG(Inventory) AS AvgInventory
FROM FactTable
GROUP BY ProductID;

-- Q11)-->
SELECT DISTINCT State FROM LocationTable ORDER BY State;

-- Q12)-->
SELECT ProductID, AVG(BudgetProfit) AS AvgBudgetProfit
FROM FactTable
GROUP BY ProductID
HAVING AVG(BudgetMargin) > 100;

-- Q13)-->
SELECT SUM(Sales) AS TotalSales FROM FactTable WHERE Date = '2010-01-01';

-- Q14)-->
SELECT Date, ProductID, AVG(TotalExpenses) AS AvgTotalExpenses
FROM FactTable
GROUP BY Date, ProductID;

-- Q15)-->
SELECT f.Date, f.ProductID, p.ProductType, p.Product, f.Sales, f.Profit, l.State, f.AreaCode
FROM FactTable f
JOIN ProductTable p ON f.ProductID = p.ProductID
JOIN LocationTable l ON f.AreaCode = l.AreaCode;

-- Q16)-->
SELECT Date, ProductID, Sales, 
       DENSE_RANK() OVER (ORDER BY Sales DESC) AS SalesRank
FROM FactTable;

-- Q17)-->
SELECT l.State, SUM(f.Profit) AS TotalProfit, SUM(f.Sales) AS TotalSales
FROM FactTable f
JOIN LocationTable l ON f.AreaCode = l.AreaCode
GROUP BY l.State;

-- Q18)-->
SELECT l.State, p.Product, SUM(f.Profit) AS TotalProfit, SUM(f.Sales) AS TotalSales
FROM FactTable f
JOIN ProductTable p ON f.ProductID = p.ProductID
JOIN LocationTable l ON f.AreaCode = l.AreaCode
GROUP BY l.State, p.Product;

-- Q19)-->
SELECT ProductID, Sales, Sales * 1.05 AS IncreasedSales FROM FactTable;

-- Q20)-->
SELECT f.ProductID, p.ProductType, f.Profit
FROM FactTable f
JOIN ProductTable p ON f.ProductID = p.ProductID
WHERE f.Profit = (SELECT MAX(Profit) FROM FactTable);

-- Q21)-->
DELIMITER $$

CREATE PROCEDURE GetProductsByType(IN pType VARCHAR(50))
BEGIN
    SELECT * FROM ProductTable WHERE ProductType = pType;
END $$

DELIMITER ;


-- Q22)-->
SELECT ProductID, TotalExpenses,
       CASE WHEN TotalExpenses < 60 THEN 'Profit' ELSE 'Loss' END AS ProfitOrLoss
FROM FactTable;

-- Q23)-->
SELECT YEARWEEK(Date) AS Week, ProductID, SUM(Sales) AS TotalSales
FROM FactTable
GROUP BY YEARWEEK(Date), ProductID WITH ROLLUP;

-- Q24)-->
SELECT AreaCode FROM FactTable
UNION
SELECT AreaCode FROM LocationTable;

SELECT AreaCode FROM FactTable
INTERSECT
SELECT AreaCode FROM LocationTable;

-- Q25)-->
DELIMITER $$

CREATE FUNCTION GetProductCountByType(pType VARCHAR(50)) RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE productCount INT;
    SELECT COUNT(*) INTO productCount FROM ProductTable WHERE ProductType = pType;
    RETURN productCount;
END $$

DELIMITER ;

SELECT GetProductCountByType('Beverage');



-- Q26)-->
UPDATE ProductTable SET ProductType = 'Tea' WHERE ProductID = 1;
-- To undo
UPDATE ProductTable SET ProductType = 'Coffee' WHERE ProductID = 1;

-- Q27)-->
SELECT Date, ProductID, Sales FROM FactTable WHERE TotalExpenses BETWEEN 100 AND 200;

-- Q28)-->
SET SQL_SAFE_UPDATES = 0;

DELETE FROM ProductTable WHERE Type = 'Regular';

SET SQL_SAFE_UPDATES = 1;


-- Q29)-->  
SELECT Product, ASCII(SUBSTRING(Product, 5, 1)) AS FifthCharASCII FROM ProductTable;

 
  
 
 
 
 




 
